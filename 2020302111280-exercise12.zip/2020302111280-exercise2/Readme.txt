首先解压压缩包到webapps，然后编写index.html,配置servlet，对应的url路径为/Servlet1。最后运行即可。
遇到的问题：由于拼写错误找bug找了很长时间。